/*
Optify Bot - main file (bot.js)
Replace this with the full code I gave you earlier in ChatGPT canvas.
*/
console.log("Optify Bot loaded. Use 'node bot.js' to run.");
