# Optify Bot

A Discord.js v14 bot for handling store orders, tickets, and catalog.

## Setup

1. Clone this repo
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and add your bot token + IDs
4. Run locally:
   ```bash
   npm start
   ```

## Deploy on Render

1. Push repo to GitHub
2. Connect repo on Render -> New Web Service
3. Set Build Command: `npm install`
4. Set Start Command: `npm start`
5. Add environment variables (from `.env.example`) in Render dashboard
